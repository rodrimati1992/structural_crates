/*!
Contains the Structural trait
*/

/// Marker trait for types that implement some field accessor traits.
pub trait Structural {}
