#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub(crate) enum StructOrEnum {
    Struct,
    Enum,
}
